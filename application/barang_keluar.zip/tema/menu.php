
<body class="hold-transition sidebar-mini layout-fixed control-sidebar-slide-open layout-navbar-fixed pace-info">

  <div class="wrapper">

    <nav class="main-header navbar navbar-expand navbar-white navbar-light">

      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-info" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-info"><marquee><b>S I M I S T I K TALA - Sistem Informasi Manajemen Logistik</b></marquee></a>
        </li>
      </ul>

      <ul class="navbar-nav ml-auto">

        <li class="nav-item">
          <a class="nav-link" href="<?= site_url('admin/Beranda/update');?>">
            <i class="fas fa-user"></i>
          </a>
        </li>

        <?php $jnotif = $this->db->query("SELECT * FROM `barang_keluar` JOIN puskesmas ON barang_keluar.id_puskesmas=puskesmas.id_puskesmas WHERE barang_keluar.status_barang_keluar='Belum Terkonfirmasi' ORDER BY barang_keluar.id_barang_keluar DESC"); ?>

        <li class="nav-item dropdown">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="far fa-bell"></i>
            <span class="badge badge-warning navbar-badge"><?= $jnotif->num_rows(); ?></span>
          </a>
          <div class="dropdown-menu dropdown-menu-xl dropdown-menu-right">
            <span class="dropdown-item dropdown-header">Pemberitahuan Permintaan</span>
            <?php foreach ($jnotif->result() as $dtnotif) : ?>
            <div class="dropdown-divider"></div>
            <a href="<?= base_url();?>admin/Permintaan/update/<?= $dtnotif->id_barang_keluar; ?>" class="dropdown-item">
              <?= $dtnotif->nama_puskesmas;?>
              <span class="float-right text-muted text-sm"><?= format_indo($dtnotif->tanggal_pengajuan);?></span>
            </a>
            <div class="dropdown-divider"></div>
            <?php endforeach;?>
            <a href="<?= base_url('admin/Permintaan')?>" class="dropdown-item dropdown-footer">Lihat semua permintaan PKM</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>

      </ul>
    </nav>
    <aside class="main-sidebar elevation-4 sidebar-light-info">
      <a href="" class="brand-link bg-info text-center">
        <img src="<?= base_url('assets/logo2.png');?>" alt="AdminLTE Logo" class="brand-image" style="">
        <span class="brand-text font-weight-light text-center"><b>S I M I S T I K </b>TALA</span>
      </a>

      <div class="sidebar">
        <div class="user-panel mt-3 pb-3 d-flex">
          <div class="image">
            <img src="<?= base_url();?>profil/<?= $this->session->userdata('foto_pengguna');?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="#" class="d-block text-info"><?= $this->session->userdata('nama_pengguna');?></a>
          </div>
        </div>

        <nav class="">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-header">Menu</li>
            <li class="nav-item ">
              <a href="<?= base_url('admin/Beranda');?>" class="nav-link <?= ($menu == "Beranda") ? "active" : "";?>">
                <i class="nav-icon fas fa-home"></i>
                <p>
                  Beranda
                </p>
              </a>
            </li>

            <li class="nav-item ">
              <a href="<?= base_url('admin/Barang');?>" class="nav-link <?= ($menu == "Barang" ) ? "active" : "";?>">
                <i class="nav-icon fas fa-book"></i>
                <p>
                  Obat/BMHP IFK
                </p>
              </a>
            </li>

            <li class="nav-item ">
              <a href="<?= base_url();?>admin/Puskesmas" class="nav-link <?= ($menu == "Daftar PKM") ? "active" : "";?>">
                <i class="nav-icon fas fa-hospital"></i>
                <p>
                  Daftar PKM
                </p>
              </a>
            </li>

            <li class="nav-item ">
              <a href="<?= base_url('admin/Permintaan');?>" class="nav-link <?= ($menu == "Permintaan" ) ? "active" : "";?>">
                <i class="nav-icon fas fa-list"></i>
                <p>
                  Permintaan PKM
                </p>
              </a>
            </li>

            <li class="nav-item <?= ($menu == "Barang_masuk" OR $menu == "Barang_keluar") ? "menu-open" : "";?>">
              <a href="#" class="nav-link <?= ($menu == "Barang_masuk" OR $menu == "Barang_keluar") ? "active" : "";?>">
                <i class="nav-icon fas fa-edit"></i>
                <p>
                  Transaksi IFK
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?= base_url('admin/Barang_masuk');?>" class="nav-link <?= ($menu == "Barang_masuk") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Penerimaan Obat/BMPH</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?= base_url('admin/Barang_keluar');?>" class="nav-link <?= ($menu == "Barang_keluar") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Pengeluaran Obat/BMPH</p>
                  </a>
                </li>

              </ul>
            </li>

            <li class="nav-item <?= ($menu == "Laporan" OR $menu == "Laporan2") ? "menu-open" : "";?>">
              <a href="#" class="nav-link <?= ($menu == "Laporan" OR $menu == "Laporan2") ? "active" : "";?>">
                <i class="nav-icon fas fa-copy"></i>
                <p>
                  Laporan
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                
                <li class="nav-item">
                  <a href="<?= base_url()?>admin/Laporan/DINAMIKA" class="nav-link <?= ($menu == "Laporan") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Dinamika IFK</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?= base_url()?>admin/Laporan/LPLPO" class="nav-link <?= ($menu == "Laporan2") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>LPLPO</p>
                  </a>
                </li>

              </ul>
            </li>

            <li class="nav-item <?= ($menu == "Pengguna" OR $menu == "Satuan" OR $menu == "Sumber" OR $menu == "Asal") ? "menu-open" : "";?>">
              <a href="#" class="nav-link <?= ($menu == "Pengguna" OR $menu == "Satuan" OR $menu == "Sumber" OR $menu == "Asal") ? "active" : "";?>">
                <i class="nav-icon fas fa-database"></i>
                <p>
                  Kelola Data
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">

                <li class="nav-item">
                  <a href="<?= base_url();?>admin/Asal" class="nav-link <?= ($menu == "Asal") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Sumber Dana</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?= base_url();?>admin/Sumber" class="nav-link <?= ($menu == "Sumber") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Sumber Barang</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?= base_url();?>admin/Satuan" class="nav-link <?= ($menu == "Satuan") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Satuan</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?= base_url();?>admin/Pengguna" class="nav-link <?= ($menu == "Pengguna") ? "active" : "";?>">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Pengguna</p>
                  </a>
                </li>

              </ul>

              <li class="nav-item ">
                <a href="<?= base_url('Login/proses_logout');?>" class="nav-link tombol-logout">
                  <i class="nav-icon fas fa-power-off"></i>
                  <p>
                    Logout
                  </p>
                </a>
              </li>
            </li>
          </ul>
        </nav>
      </div>
    </aside>