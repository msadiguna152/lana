
<footer class="main-footer">
  <img src="<?= base_url('assets/logo_dinkes.png');?>" alt="Dinkes Logo" class="img img-fluid ml-3" style="height: 25px;">
  <img src="<?= base_url('assets/logo_tala.png');?>" alt="Kab. Tala Logo" class="img img-fluid ml-3" style="height: 25px;">
  <img src="<?= base_url('assets/logo2.png');?>" alt="Simistik Tala Logo" class="img img-fluid ml-3" style="height: 25px;">
  <div class="float-right d-none d-sm-inline-block">
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>All rights reserved.
  </div>
</footer>
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?= base_url('assets/');?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?= base_url('assets/');?>plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/');?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/');?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('assets/');?>dist/js/adminlte.js"></script>
<script src="<?= base_url('assets/');?>dist/js/pages/dashboard.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?= base_url('assets/');?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/');?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/');?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url('assets/');?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?= base_url('assets/');?>plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<!-- pace-progress -->
<script src="<?= base_url('assets/');?>plugins/pace-progress/pace.min.js"></script>
<!-- Select2 -->
<script src="<?= base_url('assets/')?>plugins/select2/js/select2.full.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Bootstrap Switch -->
<script src="<?= base_url('assets/')?>plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>

<script type="text/javascript">
  $("input[data-bootstrap-switch]").each(function(){
    $(this).bootstrapSwitch('state', $(this).prop('checked'));
  })

  const flashData = $('.flash-data').data('flashdata');
  const flashData2 = $('.flash-data2').data('flashdata');
  const flashData3 = $('.flash-data3').data('flashdata');

  console.log(flashData3);
  if (flashData) {
    if (flashData=='berhasil_login') {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: 'Anda berhasil login sebagai admin!',
        showConfirmButton: true,
        // timer: 1000
      })
    } else {
      Swal.fire({
        position: 'center',
        icon: 'success',
        title: 'Data berhasil '+flashData+'!',
        showConfirmButton: false,
        timer: 1000
      })
    }
    
  };

  if (flashData3) {
    Swal.fire({
      position: 'center',
      icon: 'warning',
      title: 'Perhatian!',
      html: '<label class="text text-danger">'+flashData3+'<label>',
      showConfirmButton: true,
    })
  };

  $('.tombol-hapus').on('click', function(e) {
    e.preventDefault();
    const href = $(this).attr('href');

    Swal.fire({
      title: 'Apakah anda yakin?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, hapus!',
      cancelButtonText: 'Batal!',
    }).then((result) => {
      if (result.value) {
        document.location.href = href;
      }
    })
  });

  $('.tombol-logout').on('click', function(e) {
    e.preventDefault();
    const href = $(this).attr('href');

    Swal.fire({
      title: 'Apakah anda yakin?',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, logout!',
      cancelButtonText: 'Batal!',
    }).then((result) => {
      if (result.value) {
        document.location.href = href;
      }
    })
  })
</script>
<script>
  $(function () {

    screenWidth = window.screen.width;
    screenHeight = window.screen.height;

    if (screenHeight<450) {
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
        language: {
          url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json',
        },

      });
    } else {
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": false,
        language: {
          url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json',
        },
      });
    };

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    });
  });
</script>

<script>
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }
</script>

<script type="text/javascript">
  $(function () {
    $("#btnSubmit").click(function () {
      var password = $("#txtPassword").val();
      var confirmPassword = $("#txtConfirmPassword").val();
      if (password != confirmPassword) {
        alert("Masukan konfirmasi password dengan benar!");
        return false;
      }
      return true;
    });
  });
</script>

<script type="text/javascript">
  $(document).ready(function() {
    cek_select();
    $("#add-delete").hide();
    $("#get_tabel").find("select").select2({theme: 'bootstrap4'});
    $("#add-more").on('click', function (e) {
      // remove select2 from the row to be cloned
      var origin = $("#get_tabel tbody tr:last");
      origin.find('.select2-hidden-accessible').select2('destroy');
      // clone the origin row 
      var newrow = origin.clone();
      // reset new row values
      newrow.find(':input').val('');
      newrow.find(':input').attr("disabled", false);
      newrow.find('#label_nama_satuan').html('');
      newrow.find('#label_klasifikasi').html('');
      newrow.find('#label_harga_barang').html('');
      newrow.find('#label_nama_sumber').html('');

      // menghitung jumlah tr
      var no = $('#get_tabel tbody').find('tr').length;
      // $('#nomor').html(no);
      newrow.find('#nomor').html(no+1);
      // add the new row to the #get_tabel tbody
      $("#get_tabel tbody").append(newrow);
      if (no<=1) {
        $("#add-delete").hide();
      } else {
        $("#add-delete").show();
      }
      //reapply select2 to origin and newRow
      origin.find('.select2').select2({theme: 'bootstrap4'});
      newrow.find('.select2').select2({theme: 'bootstrap4'});
      $("#add-delete").show();
      cek_select();
    });

    $("#add-delete").on('click', function (e) {
      var origin = $("#get_tabel tbody tr:last");
      origin.remove();
      var no = $('#get_tabel tbody').find('tr').length;
      if (no<=1) {
        $("#add-delete").hide();
      } else {
        $("#add-delete").show();
      }
      cek_select();
    });

    function cek_select() {
      $(".select2").change(function() {
        var origin = $(this).closest("tr");

        var cek_barang = $('option:selected',this).val();
        if (cek_barang=='Hapus Barang') {
          origin.find('#label_nama_satuan').html('-');
          origin.find('#label_klasifikasi').html('-');
          origin.find('#label_nama_sumber').html('-');
          origin.find('#label_harga_barang').html('-');
          origin.find('#no_batch').attr("disabled", true);
          origin.find('#stok_barang_masuk').attr("disabled", true);
          origin.find('#harga_barang_masuk').attr("disabled", true);
          origin.find('#expire_date').attr("disabled", true);
          origin.find('.barang').attr('name', 'NULL');
        } else {
          origin.find('#no_batch').attr("disabled", false);
          origin.find('#stok_barang_masuk').attr("disabled", false);
          origin.find('#harga_barang_masuk').attr("disabled", false);
          origin.find('#expire_date').attr("disabled", false);
          origin.find('.barang').attr('name', 'id_barang[]');

          var nama_satuan = $('option:selected',this).data("nama_satuan");
          origin.find('#label_nama_satuan').html(nama_satuan);

          var klasifikasi = $('option:selected',this).data("klasifikasi");
          origin.find('#label_klasifikasi').html(klasifikasi);

          var nama_sumber = $('option:selected',this).data("nama_sumber");
          origin.find('#label_nama_sumber').html(nama_sumber);

          var harga_barang = $('option:selected',this).data("harga_barang");
          num = rupiah(harga_barang);
          origin.find('#label_harga_barang').html('Rp. '+num);
        }

      });

    };

    cek_select2();
    $("#add-delete2").hide();
    $("#get_tabel2").find("select").select2({theme: 'bootstrap4'});
    $("#add-more2").on('click', function (e) {
      // remove select2 from the row to be cloned
      var origin = $("#get_tabel2 tbody tr:last");
      origin.find('.select2-hidden-accessible').select2('destroy');
      // clone the origin row 
      var newrow = origin.clone();
      // reset new row values
      newrow.find(':input').val('');
      newrow.find(':input').attr("disabled", false);
      newrow.find('#label_nama_satuan').html('');
      newrow.find('#label_klasifikasi').html('');
      newrow.find('#label_stok_barang').html('');
      newrow.find('#label_harga_barang').html('');

      // menghitung jumlah tr
      var no = $('#get_tabel2 tbody').find('tr').length;
      // $('#nomor').html(no);
      newrow.find('#nomor').html(no+1);
      // add the new row to the #get_tabel2 tbody
      $("#get_tabel2 tbody").append(newrow);
      if (no<=1) {
        $("#add-delete2").hide();
      } else {
        $("#add-delete2").show();
      }
      //reapply select2 to origin and newRow
      origin.find('.select2').select2({theme: 'bootstrap4'});
      newrow.find('.select2').select2({theme: 'bootstrap4'});
      $("#add-delete2").show();
      cek_select2();
    });

    $("#add-delete2").on('click', function (e) {
      var origin = $("#get_tabel2 tbody tr:last");
      origin.remove();
      var no = $('#get_tabel2 tbody').find('tr').length;
      if (no<=1) {
        $("#add-delete2").hide();
      } else {
        $("#add-delete2").show();
      }
      cek_select2();
    });

    function cek_select2() {
      $(".select2").change(function() {
        var origin = $(this).closest("tr");

        var cek_barang = $('option:selected',this).val();
        if (cek_barang=='Hapus Barang') {
          origin.find('#label_nama_satuan').html('-');
          origin.find('#label_klasifikasi').html('-');
          origin.find('#label_harga_barang').html('-');
          origin.find('#label_stok_barang').html('-');
          origin.find('#permintaan').attr("disabled", true);
          origin.find('#stok_barang_keluar').attr("disabled", true);
          origin.find('#rincian').attr("disabled", true);
          origin.find('#ed_barang_keluar').attr("disabled", true);
          origin.find('.barang').attr('name', 'NULL');
        } else {
          origin.find('#permintaan').attr("disabled", false);
          origin.find('#stok_barang_keluar').attr("disabled", false);
          origin.find('#rincian').attr("disabled", false);
          origin.find('#ed_barang_keluar').attr("disabled", false);
          origin.find('.barang').attr('name', 'id_barang[]');

          var nama_satuan = $('option:selected',this).data("nama_satuan");
          origin.find('#label_nama_satuan').html(nama_satuan);
          var klasifikasi = $('option:selected',this).data("klasifikasi");
          origin.find('#label_klasifikasi').html(klasifikasi);
          var stok_barang = $('option:selected',this).data("stok_barang");
          origin.find('#label_stok_barang').html(stok_barang);
          var harga_barang = $('option:selected',this).data("harga_barang");
          num = rupiah(harga_barang);
          origin.find('#label_harga_barang').html('Rp. '+num);
          var ed_barang = $('option:selected',this).data("ed");
          origin.find('.ed_barang').val(ed_barang);
          origin.find('.stok_barang_keluar').attr("placeholder","Maksimal "+stok_barang);
          origin.find('.stok_barang_keluar').attr("max",stok_barang);
        }

      });

    };

    function rupiah(nStr)
    {
      nStr += '';
      x = nStr.split('.');
      x1 = x[0];
      x2 = x.length > 1 ? '.' + x[1] : '';
      var rgx = /(\d+)(\d{3})/;
      while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + '.' + '$2');
      }
      return x1 + x2;
    };

    $("#keluar_karena").change(function () {
      var keluar_karena = $(this).find(':selected').val();
      var no_berita_acara = $(".no_berita_acara");
      var no_permintaan = $(".no_permintaan");
      var id_puskesmas = $(".id_puskesmas");
      var asal_permintaan = $(".asal_permintaan");
      var rincian_barang_keluar = $(".rincian_barang_keluar");
      var permintaan = $(".permintaan");
      var btn_simpan = $(".btn_simpan");

      if (keluar_karena=="Expired Date / Rusak") {
        no_berita_acara.removeAttr("hidden");
        no_permintaan.attr("hidden", true);
        id_puskesmas.attr("hidden", true);
        asal_permintaan.attr("hidden", true);
        btn_simpan.attr("disabled", false);
        rincian_barang_keluar.removeAttr("hidden");
        permintaan.removeAttr("required");
        permintaan.attr("disabled", true);
      } else if (keluar_karena=="Permintaan PKM") {
        no_berita_acara.attr("hidden", true);
        no_permintaan.removeAttr("hidden");
        id_puskesmas.removeAttr("hidden");
        asal_permintaan.attr("hidden", true);
        btn_simpan.attr("disabled", false);
        rincian_barang_keluar.removeAttr("hidden");
        permintaan.attr("disabled", false);
        permintaan.attr("required", true);
      } else if (keluar_karena=="Permintaan Non PKM") {
        no_berita_acara.attr("hidden", true);
        no_permintaan.removeAttr("hidden");
        id_puskesmas.attr("hidden", true);
        asal_permintaan.removeAttr("hidden");
        btn_simpan.attr("disabled", false);
        rincian_barang_keluar.removeAttr("hidden");
        permintaan.attr("disabled", false);
        permintaan.attr("required", true);
      } else {
        no_berita_acara.attr("hidden", true);
        no_permintaan.attr("hidden", true);
        id_puskesmas.attr("hidden", true);
        asal_permintaan.attr("hidden", true);
        btn_simpan.attr("disabled", true);
        rincian_barang_keluar.attr("hidden", true);
        permintaan.attr("disabled", true);
      };

    });

    $("#sumber_barang").change(function () {
      var sumber_barang = $(this).find(':selected').val();
      var barang = $(".barang");
      if (sumber_barang!="-") {
        barang.attr("disabled", false);
        // console.log(sumber_barang);
        $.ajax({
          url : "<?= base_url('admin/Barang_masuk/get_barang');?>",
          method : "POST",
          data : {id: sumber_barang},
          async : false,
          dataType : 'json',
          success: function(data){
            var html = '<option value="">Pilih Barang</option><option class="bg-danger" value="Hapus Barang">Hapus Barang</option>';
            var i;
            for(i=0; i<data.length; i++){
              html += '<option data-ed="'+data[i].ed_barang+'" data-nama_satuan="'+data[i].nama_satuan+'" data-klasifikasi="'+data[i].klasifikasi+'" data-harga_barang="'+data[i].harga_barang+'" data-stok_barang="'+data[i].stok_barang+'" value="'+data[i].id_barang+'">'+data[i].nama_barang+'</option>';
            };
            $('.barang').html(html);

          }
        });
      } else {
        barang.attr("disabled", true);
      };

    });

    $('#add-more').bind("click", function () {
      $('html,body').animate({ scrollTop: 9999 }, 'slow');
    });

  });
</script>

</body>
</html>
